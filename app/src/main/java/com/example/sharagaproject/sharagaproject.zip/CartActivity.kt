package com.example.sharagaproject

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class CartActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cart)

        val db = DBHelper(this, null)
        val sharedPref = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
        val userId = sharedPref.getInt("USER_ID", -1)

        val cartList: RecyclerView = findViewById(R.id.cartList)
        cartList.layoutManager = LinearLayoutManager(this)

        val linkToList: TextView = findViewById(R.id.link_to_list)

        linkToList.setOnClickListener {
            val intent = Intent(this, ItemsActivity::class.java)
            startActivity(intent)
        }

        fun updateCart() {
            val items = db.getUserCart(userId)
            cartList.adapter = CartAdapter(items, this) { item ->
                db.removeFromCart(userId, item.id)
                updateCart()
            }
        }

        updateCart()
    }
}