package com.example.sharagaproject

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBHelper(val context: Context, val factory: SQLiteDatabase.CursorFactory?) :
    SQLiteOpenHelper(context, "app_db", factory, 2) {

    override fun onCreate(db: SQLiteDatabase?) {
        db!!.execSQL("CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, login TEXT, email TEXT, password TEXT)")

        db.execSQL("CREATE TABLE items (id INTEGER PRIMARY KEY AUTOINCREMENT, image TEXT, title TEXT, desc TEXT, item_text TEXT, price INTEGER)")

        db.execSQL("CREATE TABLE cart (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, item_id INTEGER)")

        insertInitialItems(db)
    }

    private fun insertInitialItems(db: SQLiteDatabase) {
        val items = listOf(
            Item(1, "telegram_klpafdov7e", "луна геншн импкт",
                "бквы плтные", "на месяц", 300),
            Item(2, "telegram_klpafdov7e", "140 мегаящиков",
                "та самая акция", "через 10 минут пропадёт", 179),
            Item(3, "telegram_klpafdov7e", "авп драгон лор",
                "настоящий с завода", "*с завода по производству лапши, которую я вешаю вам на уши", 300)
        )
        for (item in items) {
            val v = ContentValues()
            v.put("image", item.image)
            v.put("title", item.title)
            v.put("desc", item.desc)
            v.put("item_text", item.text)
            v.put("price", item.price)
            db.insert("items", null, v)
        }
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db!!.execSQL("DROP TABLE IF EXISTS users")
        db.execSQL("DROP TABLE IF EXISTS items")
        db.execSQL("DROP TABLE IF EXISTS cart")
        onCreate(db)
    }

    fun addUser(user: User) {
        val values = ContentValues()
        values.put("login", user.login)
        values.put("email", user.email)
        values.put("password", user.password)

        val db = this.writableDatabase
        db.insert("users", null, values)
        db.close()
    }

    fun getUser(login: String, password: String): Boolean{
        val db = this.readableDatabase
        val result = db.rawQuery("SELECT * FROM users WHERE login = '$login' AND password = '$password'", null)
        val exists = result.moveToFirst()
        result.close()
        return exists
    }

    fun getUserId(login: String, password: String): Int {
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT id FROM users WHERE login = ? AND password = ?", arrayOf(login, password))
        val id = if (cursor.moveToFirst()) cursor.getInt(0) else -1
        cursor.close()
        return id
    }

    fun getAllItems(): ArrayList<Item> {
        val items = ArrayList<Item>()
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM items", null)
        while (cursor.moveToNext()) {
            items.add(Item(
                cursor.getInt(0),
                cursor.getString(1),
                cursor.getString(2),
                cursor.getString(3),
                cursor.getString(4),
                cursor.getInt(5)
            ))
        }
        cursor.close()
        return items
    }

    fun addToCart(userId: Int, itemId: Int) {
        val db = this.writableDatabase
        val v = ContentValues()
        v.put("user_id", userId)
        v.put("item_id", itemId)
        db.insert("cart", null, v)
        db.close()
    }

    fun getUserCart(userId: Int): ArrayList<Item> {
        val items = ArrayList<Item>()
        val db = this.readableDatabase
        val query = """
            SELECT items.* FROM items 
            JOIN cart ON items.id = cart.item_id 
            WHERE cart.user_id = ?
        """
        val cursor = db.rawQuery(query, arrayOf(userId.toString()))
        while (cursor.moveToNext()) {
            items.add(
                Item(
                    cursor.getInt(0),
                    cursor.getString(1),
                    cursor.getString(2),
                    cursor.getString(3),
                    cursor.getString(4),
                    cursor.getInt(5)
                )
            )
        }
        cursor.close()
        return items
    }

    fun removeFromCart(userId: Int, itemId: Int) {
        val db = this.writableDatabase
        db.delete("cart", "user_id = ? AND item_id = ?", arrayOf(userId.toString(), itemId.toString()))
        db.close()
    }
}