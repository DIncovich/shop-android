package com.example.sharagaproject

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val userLogin: EditText = findViewById(R.id.user_login)
        val userMail: EditText = findViewById(R.id.user_mail)
        val userPass: EditText = findViewById(R.id.user_pass)
        val button: Button = findViewById(R.id.button)
        val linkToLogin: Button = findViewById(R.id.link_to_reg)

        button.setOnClickListener {
            val login = userLogin.text.toString().trim()
            val email = userMail.text.toString().trim()
            val password = userPass.text.toString().trim()

            if (login == "" || email == "" || password == "")
                Toast.makeText(this, "Не все поля заполнены", Toast.LENGTH_LONG).show()
            else {
                val user = User(login, email, password)
                val db = DBHelper(this, null)
                db.addUser(user)

                Toast.makeText(this, "Вы зарегистрировались", Toast.LENGTH_LONG).show()

                userLogin.text.clear()
                userMail.text.clear()
                userPass.text.clear()
            }
        }
    linkToLogin.setOnClickListener {
        val intent = Intent(this, AuthActivity::class.java)
        startActivity(intent)
    }

    }
}